# Handoff: Daily Todo App (Today / Tomorrow)

## Overview
A deliberately minimal personal task app with exactly two buckets — **Today** and **Tomorrow**. No projects, tags, or long-term planning. Fast capture, fast completion. Targets: **mobile web** (phone) and **iPad web**.

The chosen designs are:
- **Phone (option 2a)** — dense single-screen list showing both days, gesture-driven, quick-add bar at the bottom.
- **iPad (option 4a)** — no sidebar; Today and Tomorrow as two side-by-side columns, each with its own add line.

## About the Design Files
The files in this bundle are **design references created in HTML** — interactive prototypes showing intended look and behavior, not production code to copy directly. The task is to **recreate these designs in the target codebase's existing environment** (React, Vue, Svelte, etc.) using its established patterns and libraries. If no frontend framework exists yet, choose the most appropriate one for a small offline-friendly web app (e.g. React + Vite, or plain web components) and implement the designs there.

`Todo App.dc.html` contains all design iterations. **Implement only options 2a (phone) and 4a (iPad).** Other options (1a, 1b, 1c, 3a) are exploration history — ignore them. `ios-frame.jsx` is a device-bezel used for presentation only — do not implement it.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and interactions are final. Recreate pixel-perfectly.

## Design System — WOODWERD
All tokens come from `ds/colors_and_type.css` (included). Key values:

- Background: `#F9F7F3` (canvas-warm) — never pure white
- Surface (bars): `#FDFCFA`
- Primary text: `#0C0B09` (ink-900); secondary `#6B6560`; muted/placeholder `#948E87`
- Dividers: `#DDD8D1` (1px); emphasis borders `#C4BDB5`
- Accent (amber gold): `#C4944A`; press/hover-dark `#A87830`
- "Move" swipe underlay: `#46433D`
- Fonts: **Gotham** (body/headings; 400 Book, 700 Bold), **CargoD** (large editorial display words), **Roboto** (UI labels, buttons, counts). Font files in `fonts/` (verify licensing for production).
- Radius: sharp — 0–2px on UI; pills (9999px) only for the day-target chip
- Easing: `cubic-bezier(0.25, 0.1, 0.25, 1)`; durations 120/200/360ms

## Data Model
```
Task { id: string, text: string, day: 'today' | 'tomorrow', done: boolean }
```
One shared store powers both layouts (phone and iPad are the same app responsive to viewport). Persist locally (localStorage/IndexedDB) — single-user, no accounts.

## Screens

### 1. Phone — dense list (option 2a)
Viewport: standard phone (~402pt wide). Layout, top to bottom:

1. **Header** (below the iOS status-bar safe area): centered date eyebrow — Gotham Bold 10px, letter-spacing 0.18em, uppercase, `#6B6560` (e.g. "FRIDAY, JULY 3") — with a centered 36×2px amber rule (`#C4944A`) 8px below it. Padding: ~16–18px vertical after the safe-area inset (use `env(safe-area-inset-top)`).
2. **TODAY section header**: row with "TODAY" (Gotham Bold 11px, ls 0.18em, uppercase, `#0C0B09`) left, count right ("3 tasks", Roboto 11px `#948E87`). Padding 14px 20px 8px.
3. **Task rows** (Today): padding 13px 20px, bottom border 1px `#DDD8D1`. Row content: 5px amber dot (`#C4944A`, circle) + task text (Gotham 400, 15px/1.3, `#0C0B09`), gap 10px. Rows are swipeable (see Interactions).
4. **TOMORROW section header**: same style, label color `#6B6560`, top padding 26px.
5. **Task rows** (Tomorrow): same, but dot `#C4BDB5` and text `#6B6560`.
6. **Empty states**: italic Gotham 13px `#948E87` — "All clear for today." / "Nothing planned."
7. **Hint line**: centered Roboto 11px `#948E87`: "Swipe right to finish · swipe left to move".
8. **Bottom add bar** (fixed, above home-indicator safe area): background `#FDFCFA`, top border 1px `#DDD8D1`, padding 12px 18px, flex gap 10px:
   - **Day-target chip** (leftmost): pill, 1px border `#C4BDB5`, Roboto Medium 11px ls 0.06em, padding 8px 12px. Shows "TODAY" (bg `#0C0B09`, text `#F9F7F3`) or "TMRW" (bg `#C4944A`, text `#F9F7F3`). Tap toggles which day new tasks go to.
   - **Input**: flex 1, 1px border `#DDD8D1`, bg `#F9F7F3`, padding 12px 14px, Gotham 15px, radius 2px. Focus: border `#C4944A`. Placeholder follows chip: "Add for today…" / "Add for tomorrow…".
   - **Add button**: 46×46px, bg `#0C0B09`, "+" glyph Roboto Light 24px `#F9F7F3`, radius 2px. Hover bg `#C4944A`; press scale(0.97).

### 2. iPad — two columns (option 4a)
Viewport: iPad landscape/portrait (design reference at 1048×748 content). Layout:

1. **Header**: centered date eyebrow + 36×2px amber rule (same specs as phone). Padding 32px 48px 16px.
2. **Two equal columns** (CSS grid `1fr 1fr`), divided by 1px `#DDD8D1` vertical rule:
   - **Column header**: day word in CargoD 34px — "Today" `#0C0B09`, "Tomorrow" `#6B6560` — with task count right-aligned (Roboto 12px `#948E87`). Padding 8px 44px 10px.
   - **Task rows**: padding 16px 2px within 44px column gutters, bottom border 1px `#DDD8D1`; 5px dot (amber for Today, `#C4BDB5` for Tomorrow) + text Gotham 16px/1.35 (Today `#0C0B09`, Tomorrow `#6B6560`), gap 12px. Same swipe behavior as phone.
   - **Column add line** (bottom of each column): underline input (border-bottom 1px `#C4BDB5`, focus `#C4944A`, bg transparent, Gotham 16px, padding 10px 2px) + 40×40px ink "+" button (same behavior as phone). Padding 12px 44px 26px. Each column's input adds directly to that day.

Responsive rule: single-column phone layout below ~700px width; two-column iPad layout above.

## Interactions & Behavior
- **Add task**: Enter key or "+" button. Trim whitespace; ignore empty. New task appends to the end of its day's list. New rows animate in: fade + 8px translate-up, 200ms `cubic-bezier(0.25,0.1,0.25,1)`.
- **Swipe right (> 64px)** on a row → complete: row's underlay shows amber `#C4944A` with "DONE ✓" label (Gotham Bold 10px, ls 0.14em, `#FDFCFA`, left-aligned); on release the row slides right off-screen and fades (360ms), then is removed. Completed tasks are not kept.
- **Swipe left (> 64px)** → move to the other day: underlay shows dark `#46433D` with "→ TOMORROW" / "→ TODAY" label right-aligned; row snaps back (360ms) and the task moves lists.
- **Below threshold**: row springs back to rest (transform 360ms).
- **During drag**: row translates with the pointer, clamped to ±110px, no transition. Use pointer events with `setPointerCapture`; `touch-action: pan-y` so vertical scroll still works.
- **Day rollover** (implementation note, not in prototype): at local midnight, tasks with `day: 'tomorrow'` become `day: 'today'`. Unfinished Today tasks stay in Today.
- Hover states (iPad w/ pointer): text buttons → `#C4944A`; filled buttons darken/accent; press scale(0.97).

## State Management
- `tasks: Task[]` — single source of truth, persisted locally
- `draft: string` per add-input; `targetDay: 'today' | 'tomorrow'` for the phone chip
- Transient swipe state: `{ id, dx }` while dragging; `leaving: true` flag during the 380ms slide-out before removal

## Assets
- No icons or images required. The "+" and "✕" glyphs are text; the dot is a styled span.
- Fonts included in `fonts/` (Gotham, CargoD, Roboto). Gotham and CargoD are licensed faces — confirm license coverage for production web use.

## Files
- `Todo App.dc.html` — interactive prototype (all options; implement **2a** and **4a**)
- `ds/colors_and_type.css` — full WOODWERD token set and @font-face declarations
- `fonts/` — font files
- `ios-frame.jsx` — presentation-only device bezel (do not implement)
